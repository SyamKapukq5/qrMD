# Repositori Qr
Ini berfungsi untuk mendapatkan session

- Masuk link di sampinng untuk run instan.
[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsAlfa)](https://replit.com/@AzRyCb/Session-BoTzMd#.github/FUNDING.yml)
- jika ingin import ke replit klik  link dibawah
- https://replit.com/github/AzRyCb/Session-BoTzMd

## install Termux/rdp/windows/dll
```
> git clone https://github.com/AzRyCb/Session-BoTzMd
> cd Session-BoTzMd
> npm install && npm update
> node .
```
